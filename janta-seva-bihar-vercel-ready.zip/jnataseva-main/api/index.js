module.exports = require('../app');
