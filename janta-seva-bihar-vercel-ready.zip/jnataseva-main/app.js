document.addEventListener("DOMContentLoaded", () => {
  loadServices();
  loadNotices();

  const complaintForm =
    document.getElementById("complaintForm");

  if (complaintForm) {
    complaintForm.addEventListener(
      "submit",
      submitComplaint
    );
  }
});


// ======================================================
// LOAD SERVICES
// ======================================================

async function loadServices() {

  const container =
    document.getElementById("servicesContainer");

  if (!container) return;

  try {

    const response =
      await fetch("/api/services");

    const services =
      await response.json();

    container.innerHTML = "";

    if (!Array.isArray(services) || !services.length) {
      container.innerHTML =
        "<p>अभी कोई service उपलब्ध नहीं है।</p>";
      return;
    }

    services.forEach(service => {

      const card =
        document.createElement("div");

      card.className =
        "service-card";

      let icon =
        service.icon || "📄";

      // पुराने data के लिए automatic icon
      if (
        service.name &&
        service.name.includes("छात्रवृत्ति")
      ) {
        icon = "🎓";
      }

      if (
        service.name &&
        service.name.includes("जाति")
      ) {
        icon = "📑";
      }

      if (
        service.name &&
        service.name.includes("आय")
      ) {
        icon = "💰";
      }

      if (
        service.name &&
        service.name.includes("निवास")
      ) {
        icon = "🏠";
      }

      card.innerHTML = `

        <div class="service-icon">
          ${escapeHTML(icon)}
        </div>

        <h3>
          ${escapeHTML(service.name)}
        </h3>

        <p>
          ${escapeHTML(service.description)}
        </p>

        ${
          service.documents
            ? `
              <p>
                <strong>आवश्यक दस्तावेज:</strong><br>
                ${escapeHTML(service.documents)}
              </p>
            `
            : ""
        }

        ${
          service.officialUrl
            ? `
              <a
                href="${escapeHTML(service.officialUrl)}"
                target="_blank"
                rel="noopener noreferrer"
              >
                Official Portal →
              </a>
            `
            : ""
        }

      `;

      container.appendChild(card);

    });

  } catch (error) {

    console.error(
      "Services error:",
      error
    );

    container.innerHTML =
      "<p>Services load नहीं हो सकीं।</p>";
  }
}


// ======================================================
// LOAD NOTICES
// ======================================================

async function loadNotices() {

  const container =
    document.getElementById("noticesContainer");

  if (!container) return;

  try {

    const response =
      await fetch("/api/notices");

    const notices =
      await response.json();

    container.innerHTML = "";

    if (
      !Array.isArray(notices) ||
      !notices.length
    ) {

      container.innerHTML =
        "<p>अभी कोई notice उपलब्ध नहीं है।</p>";

      return;
    }

    notices.forEach(notice => {

      const div =
        document.createElement("div");

      div.className =
        "notice";

      div.innerHTML = `

        <h3>
          ${escapeHTML(notice.title)}
        </h3>

        <p>
          ${escapeHTML(notice.message)}
        </p>

      `;

      container.appendChild(div);

    });

  } catch (error) {

    console.error(
      "Notice error:",
      error
    );

    container.innerHTML =
      "<p>Notices load नहीं हो सकीं।</p>";
  }
}


// ======================================================
// SUBMIT COMPLAINT
// ======================================================

async function submitComplaint(e) {

  e.preventDefault();

  const form =
    document.getElementById(
      "complaintForm"
    );

  const result =
    document.getElementById(
      "complaintResult"
    );

  if (!form || !result) return;

  const formData =
    new FormData(form);

  result.innerHTML =
    "<p>Complaint submit हो रही है...</p>";

  try {

    const response =
      await fetch(
        "/api/complaints",
        {
          method: "POST",
          body: formData
        }
      );

    const data =
      await response.json();

    if (!data.success) {

      result.innerHTML = `
        <div class="result-card">
          <p>
            ${escapeHTML(data.message)}
          </p>
        </div>
      `;

      return;
    }

    result.innerHTML = `

      <div class="result-card">

        <h3>
          ✅ शिकायत दर्ज हो गई
        </h3>

        <p>
          आपकी Complaint ID:
        </p>

        <h2>
          ${escapeHTML(data.complaintId)}
        </h2>

        <p>
          इस ID को सुरक्षित रखें।
          इसी से complaint की स्थिति
          track कर सकते हैं।
        </p>

      </div>

    `;

    form.reset();

  } catch (error) {

    console.error(
      "Complaint error:",
      error
    );

    result.innerHTML =
      `
      <div class="result-card">
        <p>
          Server error.
          कृपया दोबारा प्रयास करें।
        </p>
      </div>
      `;
  }
}


// ======================================================
// TRACK COMPLAINT
// ======================================================

async function trackComplaint() {

  const input =
    document.getElementById(
      "trackId"
    );

  const result =
    document.getElementById(
      "trackResult"
    );

  if (!input || !result) return;

  const id =
    input.value.trim();

  if (!id) {

    alert(
      "Complaint ID डालें।"
    );

    return;
  }

  result.innerHTML =
    "<p>Searching...</p>";

  try {

    const response =
      await fetch(
        "/api/complaints/" +
        encodeURIComponent(id)
      );

    const data =
      await response.json();

    if (!data.success) {

      result.innerHTML = `

        <div class="result-card">

          <p>
            ${escapeHTML(data.message)}
          </p>

        </div>

      `;

      return;
    }

    const c =
      data.complaint;

    result.innerHTML = `

      <div class="result-card">

        <h3>
          Complaint Details
        </h3>

        <p>
          <b>ID:</b>
          ${escapeHTML(c.complaintId)}
        </p>

        <p>
          <b>Category:</b>
          ${escapeHTML(c.category)}
        </p>

        <p>
          <b>Village:</b>
          ${escapeHTML(c.village)}
        </p>

        <p>
          <b>Status:</b>

          <span class="status">
            ${escapeHTML(c.status)}
          </span>

        </p>

        ${
          c.adminRemark
            ? `
              <p>
                <b>Admin Remark:</b>
                ${escapeHTML(
                  c.adminRemark
                )}
              </p>
            `
            : ""
        }

      </div>

    `;

  } catch (error) {

    console.error(
      "Track error:",
      error
    );

    result.innerHTML = `

      <div class="result-card">

        <p>
          Server error.
        </p>

      </div>

    `;
  }
}


// ======================================================
// SECURITY - ESCAPE HTML
// ======================================================

function escapeHTML(value) {

  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}