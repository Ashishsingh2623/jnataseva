// =====================================================
// JANTA SEVA BIHAR - ADMIN DASHBOARD
// =====================================================

document.addEventListener("DOMContentLoaded", () => {

  setDate();

  loadStats();

  loadComplaints();

  loadServices();

  loadNotices();

});


// =====================================================
// DATE
// =====================================================

function setDate() {

  const element =
    document.getElementById("todayDate");

  if (!element) return;

  const now = new Date();

  element.textContent =
    now.toLocaleDateString("hi-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });

}


// =====================================================
// STATS
// =====================================================

async function loadStats() {

  try {

    const response =
      await fetch("/api/admin/stats");

    if (!response.ok) return;

    const data =
      await response.json();

    setText(
      "totalComplaints",
      data.complaints ?? data.totalComplaints ?? 0
    );

    setText(
      "pendingComplaints",
      data.pending ?? data.pendingComplaints ?? 0
    );

    setText(
      "resolvedComplaints",
      data.resolved ?? data.resolvedComplaints ?? 0
    );

    setText(
      "totalNotices",
      data.notices ?? data.totalNotices ?? 0
    );

    setText(
      "totalServices",
      data.services ?? data.totalServices ?? 0
    );

  } catch (error) {

    console.error("Stats:", error);

  }

}


function setText(id, value) {

  const element =
    document.getElementById(id);

  if (element) {
    element.textContent = value;
  }

}


// =====================================================
// COMPLAINTS
// =====================================================

async function loadComplaints() {

  const table =
    document.getElementById(
      "complaintsTable"
    );

  if (!table) return;


  try {

    const response =
      await fetch(
        "/api/admin/complaints"
      );

    const complaints =
      await response.json();


    if (!Array.isArray(complaints) ||
        complaints.length === 0) {

      table.innerHTML = `
        <tr>
          <td colspan="7" class="loading">
            अभी कोई complaint उपलब्ध नहीं है।
          </td>
        </tr>
      `;

      return;
    }


    table.innerHTML =
      complaints.map(
        complaint => `

        <tr>

          <td>
            <strong>
              ${safe(
                complaint.complaintId ||
                complaint.id ||
                "-"
              )}
            </strong>
          </td>

          <td>
            ${safe(
              complaint.name ||
              complaint.citizenName ||
              "-"
            )}
          </td>

          <td>
            ${safe(
              complaint.location ||
              complaint.village ||
              "-"
            )}
          </td>

          <td>
            ${safe(
              complaint.category ||
              "-"
            )}
          </td>

          <td>
            ${safe(
              complaint.description ||
              "-"
            )}
          </td>

          <td>

            <select
              onchange="
                updateComplaint(
                  '${complaint.id}',
                  this.value
                )
              "
            >

              ${statusOption(
                "Submitted",
                complaint.status
              )}

              ${statusOption(
                "Pending",
                complaint.status
              )}

              ${statusOption(
                "In Progress",
                complaint.status
              )}

              ${statusOption(
                "Resolved",
                complaint.status
              )}

            </select>

          </td>

          <td>

            <button
              class="table-delete"
              onclick="
                deleteComplaint(
                  '${complaint.id}'
                )
              "
            >
              🗑️
            </button>

          </td>

        </tr>

      `
      ).join("");


  } catch (error) {

    console.error(
      "Complaints:",
      error
    );

    table.innerHTML = `
      <tr>
        <td colspan="7" class="loading">
          Complaints load नहीं हो सकीं।
        </td>
      </tr>
    `;

  }

}


function statusOption(
  value,
  current
) {

  return `
    <option
      value="${value}"
      ${current === value ? "selected" : ""}
    >
      ${value}
    </option>
  `;

}


async function updateComplaint(
  id,
  status
) {

  try {

    const response =
      await fetch(
        `/api/admin/complaints/${id}`,
        {
          method: "PUT",

          headers: {
            "Content-Type":
              "application/json"
          },

          body: JSON.stringify({
            status: status
          })
        }
      );


    if (!response.ok) {

      alert(
        "Complaint status update नहीं हुआ।"
      );

      return;
    }


    loadComplaints();

    loadStats();


  } catch (error) {

    console.error(error);

    alert(
      "Server error आया।"
    );

  }

}


async function deleteComplaint(id) {

  if (
    !confirm(
      "क्या आप इस complaint को delete करना चाहते हैं?"
    )
  ) {
    return;
  }


  try {

    const response =
      await fetch(
        `/api/admin/complaints/${id}`,
        {
          method: "DELETE"
        }
      );


    if (!response.ok) {

      alert(
        "Complaint delete नहीं हुई।"
      );

      return;
    }


    loadComplaints();

    loadStats();


  } catch (error) {

    console.error(error);

  }

}


// =====================================================
// SERVICES
// =====================================================

async function loadServices() {

  const container =
    document.getElementById(
      "servicesGrid"
    );

  if (!container) return;


  try {

    const response =
      await fetch("/api/services");

    if (!response.ok) {
      throw new Error("Services API failed");
    }

    const services =
      await response.json();


    if (!Array.isArray(services) ||
        services.length === 0) {

      container.innerHTML = `
        <div class="loading">
          अभी कोई service उपलब्ध नहीं है।
        </div>
      `;

      setText(
        "totalServices",
        0
      );

      return;
    }


    setText(
      "totalServices",
      services.length
    );


    container.innerHTML =
      services.map(
        service => `

        <div class="service-card-admin">

          <div class="service-top">

            <div class="service-title">

              <div class="service-icon">
                ${safe(
                  service.icon || "📄"
                )}
              </div>

              <div>

                <h3>
                  ${safe(
                    service.name ||
                    "Unnamed Service"
                  )}
                </h3>

                <span class="category-badge">
                  ${safe(
                    service.category ||
                    "Government Service"
                  )}
                </span>

              </div>

            </div>

          </div>


          <p class="service-description">
            ${safe(
              service.description ||
              "Service information available."
            )}
          </p>


          <div class="service-actions">

            <button
              class="edit-btn"
              onclick="
                editService(
                  '${service.id}'
                )
              "
            >
              ✏️ Edit
            </button>

            <button
              class="delete-btn"
              onclick="
                deleteService(
                  '${service.id}'
                )
              "
            >
              🗑️ Delete
            </button>

          </div>

        </div>

      `
      ).join("");


  } catch (error) {

    console.error(
      "Services:",
      error
    );

    container.innerHTML = `
      <div class="loading">
        Services load नहीं हो सकीं।
      </div>
    `;

  }

}


// =====================================================
// ADD SERVICE
// =====================================================

function openAddService() {

  document.getElementById(
    "serviceForm"
  ).reset();


  document.getElementById(
    "serviceId"
  ).value = "";


  document.getElementById(
    "serviceIcon"
  ).value = "📄";


  document.getElementById(
    "serviceModalTitle"
  ).textContent =
    "Add Service";


  document.getElementById(
    "serviceModal"
  ).classList.add("show");

}


// =====================================================
// EDIT SERVICE
// =====================================================

async function editService(id) {

  try {

    const response =
      await fetch(
        `/api/services/${id}`
      );


    if (!response.ok) {

      alert(
        "Service details नहीं मिलीं।"
      );

      return;
    }


    const result =
      await response.json();


    const service =
      result.service ||
      result;


    document.getElementById(
      "serviceId"
    ).value =
      service.id || id;


    document.getElementById(
      "serviceName"
    ).value =
      service.name || "";


    document.getElementById(
      "serviceCategory"
    ).value =
      service.category || "";


    document.getElementById(
      "serviceIcon"
    ).value =
      service.icon || "📄";


    document.getElementById(
      "serviceDescription"
    ).value =
      service.description || "";


    document.getElementById(
      "serviceDocuments"
    ).value =
      service.documents || "";


    document.getElementById(
      "serviceOfficialUrl"
    ).value =
      service.officialUrl ||
      service.official_url ||
      "";


    document.getElementById(
      "serviceModalTitle"
    ).textContent =
      "Edit Service";


    document.getElementById(
      "serviceModal"
    ).classList.add("show");


  } catch (error) {

    console.error(error);

    alert(
      "Service load करने में problem हुई।"
    );

  }

}


// =====================================================
// SAVE SERVICE
// =====================================================

async function saveService(event) {

  event.preventDefault();


  const id =
    document.getElementById(
      "serviceId"
    ).value;


  const data = {

    name:
      document.getElementById(
        "serviceName"
      ).value.trim(),

    category:
      document.getElementById(
        "serviceCategory"
      ).value.trim(),

    icon:
      document.getElementById(
        "serviceIcon"
      ).value.trim() || "📄",

    description:
      document.getElementById(
        "serviceDescription"
      ).value.trim(),

    documents:
      document.getElementById(
        "serviceDocuments"
      ).value.trim(),

    officialUrl:
      document.getElementById(
        "serviceOfficialUrl"
      ).value.trim()

  };


  try {

    let url =
      "/api/admin/services";

    let method =
      "POST";


    if (id) {

      url =
        `/api/admin/services/${id}`;

      method =
        "PUT";

    }


    const response =
      await fetch(
        url,
        {
          method: method,

          headers: {
            "Content-Type":
              "application/json"
          },

          body:
            JSON.stringify(data)
        }
      );


    const result =
      await response.json()
        .catch(() => ({}));


    if (!response.ok) {

      alert(
        result.message ||
        "Service save नहीं हुई।"
      );

      return;
    }


    closeServiceModal();


    showMessage(
      id
        ? "✅ Service updated successfully."
        : "✅ Service added successfully."
    );


    loadServices();

    loadStats();


  } catch (error) {

    console.error(error);

    alert(
      "Server से connection नहीं हो पाया।"
    );

  }

}


// =====================================================
// DELETE SERVICE
// =====================================================

async function deleteService(id) {

  if (
    !confirm(
      "क्या आप इस service को permanently delete करना चाहते हैं?"
    )
  ) {
    return;
  }


  try {

    const response =
      await fetch(
        `/api/admin/services/${id}`,
        {
          method: "DELETE"
        }
      );


    const result =
      await response.json()
        .catch(() => ({}));


    if (!response.ok) {

      alert(
        result.message ||
        "Service delete नहीं हुई।"
      );

      return;
    }


    showMessage(
      "🗑️ Service deleted successfully."
    );


    loadServices();

    loadStats();


  } catch (error) {

    console.error(error);

    alert(
      "Server error आया।"
    );

  }

}


// =====================================================
// CLOSE MODAL
// =====================================================

function closeServiceModal() {

  document.getElementById(
    "serviceModal"
  ).classList.remove("show");

}


// =====================================================
// NOTICES
// =====================================================

async function loadNotices() {

  const container =
    document.getElementById(
      "noticesGrid"
    );

  if (!container) return;


  try {

    const response =
      await fetch(
        "/api/notices"
      );


    const notices =
      await response.json();


    if (!Array.isArray(notices) ||
        notices.length === 0) {

      container.innerHTML = `
        <div class="loading">
          अभी कोई notice नहीं है।
        </div>
      `;

      return;
    }


    container.innerHTML =
      notices.map(
        notice => `

        <div class="notice-card-admin">

          <div>

            <h3>
              ${safe(
                notice.title ||
                "Notice"
              )}
            </h3>

            <p>
              ${safe(
                notice.message ||
                notice.description ||
                ""
              )}
            </p>

          </div>


          <button
            class="delete-btn"
            onclick="
              deleteNotice(
                '${notice.id}'
              )
            "
          >
            🗑️ Delete
          </button>

        </div>

      `
      ).join("");


  } catch (error) {

    console.error(
      "Notices:",
      error
    );

    container.innerHTML = `
      <div class="loading">
        Notices load नहीं हो सके।
      </div>
    `;

  }

}


async function addNotice() {

  const title =
    prompt(
      "Notice का title डालें:"
    );


  if (!title) return;


  const message =
    prompt(
      "Notice का message डालें:"
    );


  if (!message) return;


  try {

    const response =
      await fetch(
        "/api/admin/notices",
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json"
          },

          body:
            JSON.stringify({
              title,
              message
            })
        }
      );


    if (!response.ok) {

      alert(
        "Notice add नहीं हुआ।"
      );

      return;
    }


    alert(
      "✅ Notice successfully added."
    );


    loadNotices();

    loadStats();


  } catch (error) {

    console.error(error);

  }

}


async function deleteNotice(id) {

  if (
    !confirm(
      "क्या आप इस notice को delete करना चाहते हैं?"
    )
  ) {
    return;
  }


  try {

    const response =
      await fetch(
        `/api/admin/notices/${id}`,
        {
          method: "DELETE"
        }
      );


    if (!response.ok) {

      alert(
        "Notice delete नहीं हुआ।"
      );

      return;
    }


    loadNotices();

    loadStats();


  } catch (error) {

    console.error(error);

  }

}


// =====================================================
// MESSAGE
// =====================================================

function showMessage(message) {

  const element =
    document.getElementById(
      "serviceMessage"
    );


  element.textContent =
    message;


  element.classList.add(
    "show"
  );


  setTimeout(() => {

    element.classList.remove(
      "show"
    );

  }, 3000);

}


// =====================================================
// LOGOUT
// =====================================================

function logout() {

  window.location.href =
    "/admin/";

}


// =====================================================
// HTML SECURITY
// =====================================================

function safe(value) {

  return String(
    value ?? ""
  )

    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

}