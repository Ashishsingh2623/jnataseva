# Janta Seva Bihar — Vercel Ready

The UI and existing feature set are kept unchanged. The server-side JSON/file persistence has been replaced with Neon Postgres, and complaint attachments use Vercel Blob.

## Vercel setup
1. Import this project into Vercel.
2. Add/connect a Neon Postgres integration and set `DATABASE_URL`.
3. Add/connect Vercel Blob and set `BLOB_READ_WRITE_TOKEN`.
4. Add `ADMIN_USERNAME` and `ADMIN_PASSWORD` in Vercel Environment Variables if you want credentials other than the defaults.
5. Deploy.

The first API request automatically creates the database tables and seeds the existing `data/services.json` and `data/notices.json` records when the tables are empty.

## Local development
Create `.env` from `.env.example`, fill in the variables, then run:

`npm install`

`npm start`

## Important
The included SQLite database and JSON files are retained as project/reference data. Production writes go to Neon Postgres and Vercel Blob so they persist across serverless invocations.
